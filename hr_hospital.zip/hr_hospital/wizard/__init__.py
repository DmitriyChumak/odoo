from . import disease_report_wizard
from . import personal_doctor_wizard